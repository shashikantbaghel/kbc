package kbc;

import java.awt.EventQueue;

import javax.swing.JFrame;

import java.awt.Color;
import java.awt.Dimension;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.Panel;
import java.awt.Rectangle;
import java.awt.Toolkit;

import javax.swing.JPanel;

public class Mainform implements ActionListener{

	static private JFrame frame;
	
	static List<Question> list=Resource.getQuestionList();
	
	static List<JButton> btnList=new ArrayList<JButton>();
	
	static JButton btnoption1, btnoption2,btnoption3,btnoption4,btn50_50,btnAudiance,btnPlay,btnExit,btnBack,btnRestart;
	
	static JTextArea textAreaQuestion;
	
	static JLabel lblA, lblB,lblC,lblD;
	
	static int count=-1;

	
	static JPanel panel ;
	static JLabel lblq1, lblq2,lblq3,lblq4, lblq5 ,lblq6,lblq7 , lblq8,lblq9, lblq10, lblq11, lblq12,lblq13,lblq14,lblq15;
	static List<JLabel> lblQuestionList=new ArrayList<JLabel>();
	static ImageIcon backgroundImageIcon,logoImageIcon,newbackgroundImageIcon;
	static JLabel backgroundImageLabel,logoLabel;
	static ImageIcon newactivequestionImageIcon,activequestionImageIcon;
	static Dimension screenSize;

	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
		
		UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Mainform window = new Mainform();
					window.frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			
		});
	}

	private static void loadquestion() {
		
		btnoption1.setVisible(true);
		btnoption2.setVisible(true);
		btnoption3.setVisible(true);
		btnoption4.setVisible(true);
		
		
		
		if(count<list.size()-1)
		{	
		count++;
	
		//textAreaQuestion.setText("\n"+"         "+list.get(count).getQuestion());
		textAreaQuestion.setText(list.get(count).getQuestion());
		btnoption1.setText(list.get(count).getOption1());
		btnoption2.setText(list.get(count).getOption2());
		btnoption3.setText(list.get(count).getOption3());
		btnoption4.setText(list.get(count).getOption4());
		
		if((count+1)%5==0)
	      return;
		frame.getContentPane().repaint(10, 25, 179, 220);
		lblQuestionList.get(count).setIcon(newactivequestionImageIcon);
		
		}
		else{
			
			    frame.getContentPane().removeAll();
				frame.getContentPane().repaint();
				URL url = Mainform.class.getResource("/image/Background.png");
				backgroundImageIcon=new ImageIcon(url);
				Image backgroundImage=backgroundImageIcon.getImage();
				Image newbackgroundImage=backgroundImage.getScaledInstance(screenSize.width, screenSize.height, java.awt.Image.SCALE_SMOOTH);
			    newbackgroundImageIcon=new ImageIcon(newbackgroundImage);
				backgroundImageLabel = new JLabel(newbackgroundImageIcon);
			    backgroundImageLabel.setBounds(0, 0, screenSize.width, screenSize.height);
		       
			    URL url1 = Mainform.class.getResource("/image/CONGRATS2.png");
			    ImageIcon wronganswerimageIcon = new ImageIcon(url1);
				Image wronganswerImage=wronganswerimageIcon.getImage();
				Image newwronganswerimage=wronganswerImage.getScaledInstance(screenSize.width/2, screenSize.height/2, java.awt.Image.SCALE_SMOOTH);
				ImageIcon newwronganswerimageIcon=new ImageIcon(newwronganswerimage);
				JLabel label = new JLabel(newwronganswerimageIcon);
			    label.setBounds(screenSize.width/2-screenSize.width/4, screenSize.height/8,screenSize.width/2, screenSize.height/2);
			    label.setVisible(true);
			    frame.getContentPane().add(label);
			    frame.getContentPane().add(backgroundImageLabel);
		}
		
	}
	/**
	 * Create the application.
	 */
	public Mainform() {
		loadHomeScreen();
		
	}

	private void loadHomeScreen() {
		if(null!=frame)frame.dispose();
		 screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	     
		count=-1;
		frame = new JFrame("QUIZ");
		URL url = Mainform.class.getResource("/image/Background.png");
		backgroundImageIcon=new ImageIcon(url);
		Image backgroundImage=backgroundImageIcon.getImage();
		Image newbackgroundImage=backgroundImage.getScaledInstance(screenSize.width, screenSize.height, java.awt.Image.SCALE_SMOOTH);
	    newbackgroundImageIcon=new ImageIcon(newbackgroundImage);
		backgroundImageLabel = new JLabel(newbackgroundImageIcon);
	    backgroundImageLabel.setBounds(0, 0, screenSize.width, screenSize.height);
	    
	    URL url1 = Mainform.class.getResource("/image/logo.png");
	    logoImageIcon=new ImageIcon(url1);
		Image logoImage=logoImageIcon.getImage();
		Image newlogoImage=logoImage.getScaledInstance(screenSize.width/2, screenSize.height/2, java.awt.Image.SCALE_SMOOTH);
		ImageIcon newlogoImageIcon=new ImageIcon(newlogoImage);

	    logoLabel=new JLabel(newlogoImageIcon);
	    logoLabel.setBounds(screenSize.width/2-screenSize.width/4, screenSize.height/8,screenSize.width/2, screenSize.height/2);
	   
		frame.getContentPane().setLayout(null);
		
		URL url2 = Mainform.class.getResource("/image/text_bg-short.png");
		ImageIcon homeButtonImageIcon=new ImageIcon(url2);
		Image homeButtonImage=homeButtonImageIcon.getImage();
		Image newhomeButtonImage=homeButtonImage.getScaledInstance(screenSize.width/4, 80, java.awt.Image.SCALE_SMOOTH);
		ImageIcon newhomeButtonIcon=new ImageIcon(newhomeButtonImage);

		
		btnPlay=new JButton("PLAY THE GAME",newhomeButtonIcon);
		btnPlay.setForeground(Color.white);
		btnPlay.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnPlay.setHorizontalTextPosition(JButton.CENTER);
		btnPlay.setVerticalTextPosition(JButton.CENTER);
		btnPlay.setBounds(screenSize.width/2-screenSize.width/8, screenSize.height/8+screenSize.height/2, screenSize.width/4, 80);
		frame.getContentPane().add(btnPlay);
		btnPlay.addActionListener(this);
		
		
		btnExit=new JButton("QUIT THE GAME",newhomeButtonIcon);
		btnExit.setForeground(Color.WHITE);
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnExit.setHorizontalTextPosition(JButton.CENTER);
		btnExit.setVerticalTextPosition(JButton.CENTER);
		btnExit.setBounds(screenSize.width/2-screenSize.width/8, screenSize.height/8+screenSize.height/2+100, screenSize.width/4,80);
		frame.getContentPane().add(btnExit);
		btnExit.addActionListener(this);
	
		frame.getContentPane().add(logoLabel);
		frame.getContentPane().add(backgroundImageLabel);
		frame.setBounds(0, 0, screenSize.width, screenSize.height);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.setResizable(false);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		URL url = Mainform.class.getResource("/image/text_bg-short.png");
		ImageIcon optionButtonImage=new ImageIcon(url);
		Image optionImage=optionButtonImage.getImage();
		Image newOptionImage=optionImage.getScaledInstance(screenSize.width/3, 80, java.awt.Image.SCALE_SMOOTH);
		ImageIcon newoptionIcon=new ImageIcon(newOptionImage);
		btnoption1 = new JButton("",newoptionIcon);
		btnoption1.setHorizontalTextPosition(JButton.CENTER);
		btnoption1.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnoption1.setForeground(Color.white);
		btnoption1.setBounds(screenSize.width/2-screenSize.width/3, screenSize.height/8+screenSize.height/2+60, screenSize.width/3, 80);
		frame.getContentPane().add(btnoption1);
		
		btnoption2 = new JButton("",newoptionIcon);
		btnoption2.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnoption2.setHorizontalTextPosition(JButton.CENTER);
		btnoption2.setForeground(Color.white);
		btnoption2.setBounds(screenSize.width/2+40, screenSize.height/8+screenSize.height/2+60, screenSize.width/3, 80);
		frame.getContentPane().add(btnoption2);
		
		btnoption3 = new JButton("\r\n",newoptionIcon);
		btnoption3.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnoption3.setHorizontalTextPosition(JButton.CENTER);
		btnoption3.setForeground(Color.white);
		btnoption3.setBounds(screenSize.width/2-screenSize.width/3, screenSize.height/8+screenSize.height/2+150, screenSize.width/3, 80);
		frame.getContentPane().add(btnoption3);
		
		btnoption4 = new JButton("",newoptionIcon);
		btnoption4.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnoption4.setHorizontalTextPosition(JButton.CENTER);
		btnoption4.setForeground(Color.white);
		btnoption4.setBounds(screenSize.width/2+40,  screenSize.height/8+screenSize.height/2+150, screenSize.width/3, 80);
		frame.getContentPane().add(btnoption4);

		URL url1=Mainform.class.getResource("/image/text_bg_long.png");
		ImageIcon questionImageIcon=new ImageIcon(url1);
		Image questionImage=questionImageIcon.getImage();
		Image newquestionImage=questionImage.getScaledInstance(screenSize.width/2, 100, java.awt.Image.SCALE_SMOOTH);
		ImageIcon newquestionImageIcon=new ImageIcon(newquestionImage);
		textAreaQuestion = new JTextArea(){
		      Image image = newquestionImageIcon.getImage();

		    
		      {
		        setOpaque(false);
		      }

		      public void paint(Graphics g) {
		        g.drawImage(image, 0, 0, this);
		        super.paint(g);
		      }
		    };
		textAreaQuestion.setFont(new Font("Tahoma", Font.BOLD, 24));
		textAreaQuestion.setEditable(false);
		textAreaQuestion.setForeground(Color.white);
		textAreaQuestion.setLineWrap(true);
		textAreaQuestion.setMargin( new Insets(15,45,0,45) );
		textAreaQuestion.setBounds(screenSize.width/2-screenSize.width/4, screenSize.height/8+screenSize.height/2-50, screenSize.width/2, 100);
		frame.getContentPane().add(textAreaQuestion);
		
		URL url3=Mainform.class.getResource("/image/audiance_poll2.png");
		ImageIcon audianceImageIcon=new ImageIcon(url3);
		Image audianceImage=audianceImageIcon.getImage();
		Image newaudianceImage=audianceImage.getScaledInstance(142, 122, java.awt.Image.SCALE_SMOOTH);
		ImageIcon newaudianceImageIcon=new ImageIcon(newaudianceImage);
		btnAudiance = new JButton(newaudianceImageIcon);
		btnAudiance.setBounds(screenSize.width-150, 30, 100,100);
		frame.getContentPane().add(btnAudiance);
		
		lblA = new JLabel("A");
		lblA.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblA.setForeground(Color.YELLOW);
		lblA.setBounds(screenSize.width/2-screenSize.width/3-20, screenSize.height/8+screenSize.height/2+70, 30, 61);
		frame.getContentPane().add(lblA);
		
		lblB = new JLabel("B");
		lblB.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblB.setForeground(Color.YELLOW);
		lblB.setBounds(screenSize.width/2+20, screenSize.height/8+screenSize.height/2+70, 30, 61);
		frame.getContentPane().add(lblB);
		
		lblC = new JLabel("C");
		lblC.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblC.setForeground(Color.YELLOW);
		lblC.setBounds(screenSize.width/2-screenSize.width/3-20,  screenSize.height/8+screenSize.height/2+170, 30, 67);
		frame.getContentPane().add(lblC);
		
		lblD = new JLabel("D");
		lblD.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblD.setForeground(Color.YELLOW);
		lblD.setBounds(screenSize.width/2+20,  screenSize.height/8+screenSize.height/2+170, 30, 67);
		frame.getContentPane().add(lblD);
		
		btn50_50 = new JButton("50-50");
		btn50_50.setFont(new Font("Tahoma", Font.BOLD, 24));
		btn50_50.setBounds(screenSize.width-260, 30, 100, 100);
		btn50_50.setBackground(Color.GREEN);
		btn50_50.setForeground(Color.WHITE);
		
		btnoption1.addActionListener(this);
		btnoption2.addActionListener(this);
		btnoption3.addActionListener(this);
		btnoption4.addActionListener(this);
		btn50_50.addActionListener(this);
		btnAudiance.addActionListener(this);
		btnList.clear();
		btnList.add(btnoption1);
		btnList.add(btnoption2);
		btnList.add(btnoption3);
		btnList.add(btnoption4);
		
		frame.getContentPane().add(btn50_50);
		
		panel = new JPanel();
		panel.setBackground(new Color(0, 0, 0, 0));
		panel.setBounds(10, 25, 179, 220);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		URL url4=Mainform.class.getResource("/image/question_bg.png");
		ImageIcon lblq1ImageIcon=new ImageIcon(url4);
		Image lblq1Image=lblq1ImageIcon.getImage();
		Image newlblq1Image=lblq1Image.getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
		ImageIcon newlblq1ImageIcon=new ImageIcon(newlblq1Image);
		lblq1=new JLabel(newlblq1ImageIcon);
		lblq1.setText("1");
		lblq1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblq1.setHorizontalTextPosition(JLabel.CENTER);
		lblq1.setForeground(Color.white);
		lblq1.setBounds(15, 180, 40, 40);
		panel.add(lblq1);
	
		
		
		lblq2=new JLabel(newlblq1ImageIcon);
		lblq2.setText("2");
		lblq2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblq2.setHorizontalTextPosition(JLabel.CENTER);
		lblq2.setForeground(Color.white);
		lblq2.setBounds(15, 140, 40, 40);
		panel.add(lblq2);
	
		
		lblq3=new JLabel(newlblq1ImageIcon);
		lblq3.setText("3");
		lblq3.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblq3.setHorizontalTextPosition(JLabel.CENTER);
		lblq3.setForeground(Color.white);
		lblq3.setBounds(15, 100, 40, 40);
		panel.add(lblq3);

		
		lblq4=new JLabel(newlblq1ImageIcon);
		lblq4.setText("4");
		lblq4.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblq4.setHorizontalTextPosition(JLabel.CENTER);
		lblq4.setForeground(Color.white);
		lblq4.setBounds(15, 60, 40, 40);
		panel.add(lblq4);
	
		URL url5=Mainform.class.getResource("/image/gift_pack-small.png");
		ImageIcon jackpotIcon=new ImageIcon(url5);
		lblq5 = new JLabel(jackpotIcon);
		lblq5.setBounds(15, 0, 40, 40);
		panel.add(lblq5);
		
		lblq6=new JLabel(newlblq1ImageIcon);
		lblq6.setText("6");
		lblq6.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblq6.setHorizontalTextPosition(JLabel.CENTER);
		lblq6.setForeground(Color.white);
		lblq6.setBounds(65, 180, 40, 40);
		panel.add(lblq6);

		
		lblq7=new JLabel(newlblq1ImageIcon);
		lblq7.setText("7");
		lblq7.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblq7.setHorizontalTextPosition(JLabel.CENTER);
		lblq7.setForeground(Color.white);
		lblq7.setBounds(65, 140, 40, 40);
		panel.add(lblq7);
	
		
		lblq8=new JLabel(newlblq1ImageIcon);
		lblq8.setText("8");
		lblq8.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblq8.setHorizontalTextPosition(JLabel.CENTER);
		lblq8.setForeground(Color.white);
		lblq8.setBounds(65, 100, 40, 40);
		panel.add(lblq8);
	
		
		lblq9=new JLabel(newlblq1ImageIcon);
		lblq9.setText("9");
		lblq9.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblq9.setHorizontalTextPosition(JLabel.CENTER);
		lblq9.setForeground(Color.white);
		lblq9.setBounds(65, 60, 40, 40);
		panel.add(lblq9);

		
		lblq10 = new JLabel(jackpotIcon);
		lblq10.setBounds(65, 0, 40, 40);
		panel.add(lblq10);
		
		lblq11=new JLabel(newlblq1ImageIcon);
		lblq11.setText("11");
		lblq11.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblq11.setHorizontalTextPosition(JLabel.CENTER);
		lblq11.setForeground(Color.white);
		lblq11.setBounds(110, 180, 40, 40);
		panel.add(lblq11);
	
		
		lblq12=new JLabel(newlblq1ImageIcon);
		lblq12.setText("12");
		lblq12.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblq12.setHorizontalTextPosition(JLabel.CENTER);
		lblq12.setForeground(Color.white);
		lblq12.setBounds(110, 140, 40, 40);
		panel.add(lblq12);

		
		lblq13=new JLabel(newlblq1ImageIcon);
		lblq13.setText("13");
		lblq13.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblq13.setHorizontalTextPosition(JLabel.CENTER);
		lblq13.setForeground(Color.white);
		lblq13.setBounds(110, 100, 40, 40);
		panel.add(lblq13);
	
		
		lblq14=new JLabel(newlblq1ImageIcon);
		lblq14.setText("14");
		lblq14.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblq14.setHorizontalTextPosition(JLabel.CENTER);
		lblq14.setForeground(Color.white);
		lblq14.setBounds(110, 60, 40, 40);
		panel.add(lblq14);
	
		

		
		lblq15 = new JLabel(jackpotIcon);
		lblq15.setBounds(110, 0, 40, 40);
		panel.add(lblq15);
		
		lblQuestionList.clear();
		lblQuestionList.add(lblq1);
		lblQuestionList.add(lblq2);
		lblQuestionList.add(lblq3);
		lblQuestionList.add(lblq4);
		lblQuestionList.add(lblq5);
		lblQuestionList.add(lblq6);
		lblQuestionList.add(lblq7);
		lblQuestionList.add(lblq8);
		lblQuestionList.add(lblq9);
		lblQuestionList.add(lblq10);
		lblQuestionList.add(lblq11);
		lblQuestionList.add(lblq12);
		lblQuestionList.add(lblq13);
		lblQuestionList.add(lblq14);
		lblQuestionList.add(lblq15);
		
	
		frame.getContentPane().add(logoLabel);
		frame.getContentPane().add(backgroundImageLabel);
	}

	
	@Override
	public void actionPerformed(ActionEvent e) {
			
		   URL url = Mainform.class.getResource("/image/active_question.png");
		   activequestionImageIcon=new ImageIcon(url);
		   Image activequestionImage=activequestionImageIcon.getImage();
		   Image newactivequestionImage=activequestionImage.getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
		   newactivequestionImageIcon=new ImageIcon(newactivequestionImage);
		if(e.getSource()==btnoption1)
		{
			if(list.get(count).getCorrect().equalsIgnoreCase(btnoption1.getText()))
			{
				
				try {
					  
					  
					   Clip clip=AudioSystem.getClip();
					   clip.open(AudioSystem.getAudioInputStream(getClass().getResource("/sound/applause4.wav")));
					   clip.start();
					
					   
					   Thread.sleep(clip.getMicrosecondLength()/1000);
				}
				catch (InterruptedException | LineUnavailableException | IOException | UnsupportedAudioFileException e1) {
					
					e1.printStackTrace();
				}
				if((count+1)%5==0){
					showAnimation();
				}
				else
				{
				loadquestion();
				}
			}
			else
			{
				try {
						
						Clip clip=AudioSystem.getClip();
						clip.open(AudioSystem.getAudioInputStream(getClass().getResource("/sound/smb_mariodie.wav")));
						clip.start();
						Thread.sleep(clip.getMicrosecondLength()/1000);
						
						frame.getContentPane().removeAll();
						frame.getContentPane().repaint();
						URL url2 = Mainform.class.getResource("/image/Background.png");
						backgroundImageIcon=new ImageIcon(url2);
						Image backgroundImage=backgroundImageIcon.getImage();
						Image newbackgroundImage=backgroundImage.getScaledInstance(screenSize.width, screenSize.height, java.awt.Image.SCALE_SMOOTH);
					    newbackgroundImageIcon=new ImageIcon(newbackgroundImage);
						backgroundImageLabel = new JLabel(newbackgroundImageIcon);
					    backgroundImageLabel.setBounds(0, 0, screenSize.width, screenSize.height);
					    
					    URL url3 = Mainform.class.getResource("/image/wrong.png");
						ImageIcon wronganswerimageIcon = new ImageIcon(url3);
						Image wronganswerImage=wronganswerimageIcon.getImage();
						Image newwronganswerimage=wronganswerImage.getScaledInstance(screenSize.width/2, screenSize.height/2, java.awt.Image.SCALE_SMOOTH);
						ImageIcon newwronganswerimageIcon=new ImageIcon(newwronganswerimage);
						JLabel label = new JLabel(newwronganswerimageIcon);
					    label.setBounds(screenSize.width/2-screenSize.width/4, screenSize.height/8,screenSize.width/2, screenSize.height/2);
					    label.setVisible(true);
					    

					    URL url4 = Mainform.class.getResource("/image/text_bg-short.png");
					    ImageIcon homeButtonImageIcon=new ImageIcon(url4);
						Image homeButtonImage=homeButtonImageIcon.getImage();
						Image newhomeButtonImage=homeButtonImage.getScaledInstance(screenSize.width/4, 80, java.awt.Image.SCALE_SMOOTH);
						ImageIcon newhomeButtonIcon=new ImageIcon(newhomeButtonImage);
					  
						btnRestart=new JButton("RESTART THE GAME",newhomeButtonIcon);
						btnRestart.setFont(new Font("Tahoma", Font.BOLD, 24));
						btnRestart.setHorizontalTextPosition(JButton.CENTER);
						btnRestart.setVerticalTextPosition(JButton.CENTER);
						btnRestart.setForeground(Color.white);
						btnRestart.setBounds(screenSize.width/2-screenSize.width/8, screenSize.height/8+screenSize.height/2, screenSize.width/4, 80);
				        frame.getContentPane().add(btnRestart);
				        btnRestart.addActionListener(this);
					    frame.getContentPane().add(btnRestart);
					    frame.getContentPane().add(label);
					    frame.getContentPane().add(backgroundImageLabel);
					    
						
				   
				}
				catch(Exception e1)
				{
					
				}
			}
		}
		else if(e.getSource()==btnoption2)
		{
			if(list.get(count).getCorrect().equalsIgnoreCase(btnoption2.getText()))
			{
				
				try {
						
					  
					   Clip clip=AudioSystem.getClip();
					   clip.open(AudioSystem.getAudioInputStream(getClass().getResource("/sound/applause4.wav")));
					   clip.start();
					   Thread.sleep(clip.getMicrosecondLength()/1000);
					   
					   
			} catch (InterruptedException | LineUnavailableException | IOException | UnsupportedAudioFileException e1) {
				
				e1.printStackTrace();
			}
				if((count+1)%5==0){
					showAnimation();
				}
				else
				{
				loadquestion();
				}
			}
			else
			{
				try {
					   

					
					Clip clip=AudioSystem.getClip();
					clip.open(AudioSystem.getAudioInputStream(getClass().getResource("/sound/smb_mariodie.wav")));
					clip.start();
					Thread.sleep(clip.getMicrosecondLength()/1000);
					
					frame.getContentPane().removeAll();
					frame.getContentPane().repaint();
					URL url2 = Mainform.class.getResource("/image/Background.png");
					backgroundImageIcon=new ImageIcon(url2);
					Image backgroundImage=backgroundImageIcon.getImage();
					Image newbackgroundImage=backgroundImage.getScaledInstance(screenSize.width, screenSize.height, java.awt.Image.SCALE_SMOOTH);
				    newbackgroundImageIcon=new ImageIcon(newbackgroundImage);
					backgroundImageLabel = new JLabel(newbackgroundImageIcon);
				    backgroundImageLabel.setBounds(0, 0, screenSize.width, screenSize.height);
				    
				    URL url3 = Mainform.class.getResource("/image/wrong.png");
					ImageIcon wronganswerimageIcon = new ImageIcon(url3);
					Image wronganswerImage=wronganswerimageIcon.getImage();
					Image newwronganswerimage=wronganswerImage.getScaledInstance(screenSize.width/2, screenSize.height/2, java.awt.Image.SCALE_SMOOTH);
					ImageIcon newwronganswerimageIcon=new ImageIcon(newwronganswerimage);
					JLabel label = new JLabel(newwronganswerimageIcon);
				    label.setBounds(screenSize.width/2-screenSize.width/4, screenSize.height/8,screenSize.width/2, screenSize.height/2);
				    label.setVisible(true);
				    

				    URL url4 = Mainform.class.getResource("/image/text_bg-short.png");
				    ImageIcon homeButtonImageIcon=new ImageIcon(url4);
					Image homeButtonImage=homeButtonImageIcon.getImage();
					Image newhomeButtonImage=homeButtonImage.getScaledInstance(screenSize.width/4, 80, java.awt.Image.SCALE_SMOOTH);
					ImageIcon newhomeButtonIcon=new ImageIcon(newhomeButtonImage);
				  
					btnRestart=new JButton("RESTART THE GAME",newhomeButtonIcon);
					btnRestart.setFont(new Font("Tahoma", Font.BOLD, 24));
					btnRestart.setHorizontalTextPosition(JButton.CENTER);
					btnRestart.setVerticalTextPosition(JButton.CENTER);
					btnRestart.setForeground(Color.white);
					btnRestart.setBounds(screenSize.width/2-screenSize.width/8, screenSize.height/8+screenSize.height/2, screenSize.width/4, 80);
			        frame.getContentPane().add(btnRestart);
			        btnRestart.addActionListener(this);
				    frame.getContentPane().add(btnRestart);
				    frame.getContentPane().add(label);
				    frame.getContentPane().add(backgroundImageLabel);
				     
					}
					catch(Exception e1)
					{
						
					}				
			}
		}
		else if(e.getSource()==btnoption3)
		{
			if(list.get(count).getCorrect().equalsIgnoreCase(btnoption3.getText()))
			{
				try {
				       
					   Clip clip=AudioSystem.getClip();
					   clip.open(AudioSystem.getAudioInputStream(getClass().getResource("/sound/applause4.wav")));
					   clip.start();
					   
					   
					   Thread.sleep(clip.getMicrosecondLength()/1000);
					   
			} catch (LineUnavailableException | IOException | UnsupportedAudioFileException | InterruptedException e1) {
				
				e1.printStackTrace();
			}
				if((count+1)%5==0){
					showAnimation();
				}
				else
				{
				loadquestion();
				}
			}
			else
			{
				
				try {
					  

					Clip clip=AudioSystem.getClip();
					clip.open(AudioSystem.getAudioInputStream(getClass().getResource("/sound/smb_mariodie.wav")));
					clip.start();
					Thread.sleep(clip.getMicrosecondLength()/1000);
					
					frame.getContentPane().removeAll();
					frame.getContentPane().repaint();
					URL url2 = Mainform.class.getResource("/image/Background.png");
					backgroundImageIcon=new ImageIcon(url2);
					Image backgroundImage=backgroundImageIcon.getImage();
					Image newbackgroundImage=backgroundImage.getScaledInstance(screenSize.width, screenSize.height, java.awt.Image.SCALE_SMOOTH);
				    newbackgroundImageIcon=new ImageIcon(newbackgroundImage);
					backgroundImageLabel = new JLabel(newbackgroundImageIcon);
				    backgroundImageLabel.setBounds(0, 0, screenSize.width, screenSize.height);
				    
				    URL url3 = Mainform.class.getResource("/image/wrong.png");
					ImageIcon wronganswerimageIcon = new ImageIcon(url3);
					Image wronganswerImage=wronganswerimageIcon.getImage();
					Image newwronganswerimage=wronganswerImage.getScaledInstance(screenSize.width/2, screenSize.height/2, java.awt.Image.SCALE_SMOOTH);
					ImageIcon newwronganswerimageIcon=new ImageIcon(newwronganswerimage);
					JLabel label = new JLabel(newwronganswerimageIcon);
				    label.setBounds(screenSize.width/2-screenSize.width/4, screenSize.height/8,screenSize.width/2, screenSize.height/2);
				    label.setVisible(true);
				    

				    URL url4 = Mainform.class.getResource("/image/text_bg-short.png");
				    ImageIcon homeButtonImageIcon=new ImageIcon(url4);
					Image homeButtonImage=homeButtonImageIcon.getImage();
					Image newhomeButtonImage=homeButtonImage.getScaledInstance(screenSize.width/4, 80, java.awt.Image.SCALE_SMOOTH);
					ImageIcon newhomeButtonIcon=new ImageIcon(newhomeButtonImage);
				  
					btnRestart=new JButton("RESTART THE GAME",newhomeButtonIcon);
					btnRestart.setFont(new Font("Tahoma", Font.BOLD, 24));
					btnRestart.setHorizontalTextPosition(JButton.CENTER);
					btnRestart.setVerticalTextPosition(JButton.CENTER);
					btnRestart.setForeground(Color.white);
					btnRestart.setBounds(screenSize.width/2-screenSize.width/8, screenSize.height/8+screenSize.height/2, screenSize.width/4, 80);
			        frame.getContentPane().add(btnRestart);
			        btnRestart.addActionListener(this);
				    frame.getContentPane().add(btnRestart);
				    frame.getContentPane().add(label);
				    frame.getContentPane().add(backgroundImageLabel);
					}
					catch(Exception e1)
					{
						
					}
				
			 
			}
		}
		else if(e.getSource()==btnoption4)
		{
			if(list.get(count).getCorrect().equalsIgnoreCase(btnoption4.getText()))
			{
				try {
					 
					   Clip clip=AudioSystem.getClip();
					   clip.open(AudioSystem.getAudioInputStream(getClass().getResource("/sound/applause4.wav")));
					   clip.start();
					   
					   Thread.sleep(clip.getMicrosecondLength()/1000);
					
			} catch (InterruptedException | LineUnavailableException | IOException | UnsupportedAudioFileException e1) {
				
				e1.printStackTrace();
			}
				if((count+1)%5==0){
					showAnimation();
				}
				else
				{
				loadquestion();
				}
			}
			else
			{
				try {
					   

					Clip clip=AudioSystem.getClip();
					clip.open(AudioSystem.getAudioInputStream(getClass().getResource("/sound/smb_mariodie.wav")));
					clip.start();
					Thread.sleep(clip.getMicrosecondLength()/1000);
					
					frame.getContentPane().removeAll();
					frame.getContentPane().repaint();
					URL url2 = Mainform.class.getResource("/image/Background.png");
					backgroundImageIcon=new ImageIcon(url2);
					Image backgroundImage=backgroundImageIcon.getImage();
					Image newbackgroundImage=backgroundImage.getScaledInstance(screenSize.width, screenSize.height, java.awt.Image.SCALE_SMOOTH);
				    newbackgroundImageIcon=new ImageIcon(newbackgroundImage);
					backgroundImageLabel = new JLabel(newbackgroundImageIcon);
				    backgroundImageLabel.setBounds(0, 0, screenSize.width, screenSize.height);
				    
				    URL url3 = Mainform.class.getResource("/image/wrong.png");
					ImageIcon wronganswerimageIcon = new ImageIcon(url3);
					Image wronganswerImage=wronganswerimageIcon.getImage();
					Image newwronganswerimage=wronganswerImage.getScaledInstance(screenSize.width/2, screenSize.height/2, java.awt.Image.SCALE_SMOOTH);
					ImageIcon newwronganswerimageIcon=new ImageIcon(newwronganswerimage);
					JLabel label = new JLabel(newwronganswerimageIcon);
				    label.setBounds(screenSize.width/2-screenSize.width/4, screenSize.height/8,screenSize.width/2, screenSize.height/2);
				    label.setVisible(true);
				    

				    URL url4 = Mainform.class.getResource("/image/text_bg-short.png");
				    ImageIcon homeButtonImageIcon=new ImageIcon(url4);
					Image homeButtonImage=homeButtonImageIcon.getImage();
					Image newhomeButtonImage=homeButtonImage.getScaledInstance(screenSize.width/4, 80, java.awt.Image.SCALE_SMOOTH);
					ImageIcon newhomeButtonIcon=new ImageIcon(newhomeButtonImage);
				  
					btnRestart=new JButton("RESTART THE GAME",newhomeButtonIcon);
					btnRestart.setFont(new Font("Tahoma", Font.BOLD, 24));
					btnRestart.setHorizontalTextPosition(JButton.CENTER);
					btnRestart.setVerticalTextPosition(JButton.CENTER);
					btnRestart.setForeground(Color.white);
					btnRestart.setBounds(screenSize.width/2-screenSize.width/8, screenSize.height/8+screenSize.height/2, screenSize.width/4, 80);
			        frame.getContentPane().add(btnRestart);
			        btnRestart.addActionListener(this);
				    frame.getContentPane().add(btnRestart);
				    frame.getContentPane().add(label);
				    frame.getContentPane().add(backgroundImageLabel);
					   
				       
					}
					catch(Exception e1)
					{
						
					}
				
			 
			}
		}
		else if(e.getSource()==btn50_50)
		{
		    int i=0;
		    int index=0;
			while(i<2)
			{
				
				if(!list.get(count).getCorrect().equalsIgnoreCase(btnList.get(index).getText()))
				{
					btnList.get(index).setVisible(false);
					i++;
				}
				index++;
			}
			
			btn50_50.setEnabled(false);
			
				
		}
		else if(e.getSource()==btnAudiance)
		{
			
		}
		else if(e.getSource()==btnPlay)
		{
			frame.getContentPane().removeAll();
			frame.getContentPane().repaint();
			initialize();
			loadquestion();
			
		}
		else if(e.getSource()==btnExit)
		{
			System.exit(0);
			
		}
		else if(e.getSource()==btnBack)
		{
			frame.getContentPane().removeAll();
			frame.getContentPane().repaint();
			initialize();
			loadquestion();
			chnageColorofbtnquestion();
			
		}
		else if(e.getSource()==btnRestart)
		{
			
			loadHomeScreen();
			
		}
		
		
	}

	private void chnageColorofbtnquestion() {
			
			URL url=Mainform.class.getResource("/image/active_question.png");
		   activequestionImageIcon=new ImageIcon(url);
		   Image activequestionImage=activequestionImageIcon.getImage();
		   Image newactivequestionImage=activequestionImage.getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
		   newactivequestionImageIcon=new ImageIcon(newactivequestionImage);
		for(int i=0;i<=count-1;i++)
		{
			if((i+1)%5==0)continue;
			lblQuestionList.get(i).setIcon(newactivequestionImageIcon);;
		}
		
		
	}
	

	private void showAnimation() {
		   
		    frame.getContentPane().removeAll();
			frame.getContentPane().repaint();
			URL url=Mainform.class.getResource("/image/Background.png");
			backgroundImageIcon=new ImageIcon(url);
			Image backgroundImage=backgroundImageIcon.getImage();
			Image newbackgroundImage=backgroundImage.getScaledInstance(screenSize.width, screenSize.height, java.awt.Image.SCALE_SMOOTH);
		    newbackgroundImageIcon=new ImageIcon(newbackgroundImage);
			backgroundImageLabel = new JLabel(newbackgroundImageIcon);
		    backgroundImageLabel.setBounds(0, 0, screenSize.width, screenSize.height);
	       
		    URL url1=Mainform.class.getResource("/image/gift_pack.png");
		    ImageIcon wronganswerimageIcon = new ImageIcon(url1);
			Image wronganswerImage=wronganswerimageIcon.getImage();
			Image newwronganswerimage=wronganswerImage.getScaledInstance(screenSize.width/2, screenSize.height/2, java.awt.Image.SCALE_SMOOTH);
			ImageIcon newwronganswerimageIcon=new ImageIcon(newwronganswerimage);
			JLabel label = new JLabel(newwronganswerimageIcon);
		    label.setBounds(screenSize.width/2-screenSize.width/4, screenSize.height/8,screenSize.width/2, screenSize.height/2);
		    label.setVisible(true);
		    
		    URL url2=Mainform.class.getResource("/image/text_bg-short.png");
		    ImageIcon homeButtonImageIcon=new ImageIcon(url2);
			Image homeButtonImage=homeButtonImageIcon.getImage();
			Image newhomeButtonImage=homeButtonImage.getScaledInstance(screenSize.width/4, 80, java.awt.Image.SCALE_SMOOTH);
			ImageIcon newhomeButtonIcon=new ImageIcon(newhomeButtonImage);

			
		  
			btnBack=new JButton("Back",newhomeButtonIcon);
		    btnBack.setFont(new Font("Tahoma", Font.BOLD, 24));
		    btnBack.setHorizontalTextPosition(JButton.CENTER);
		    btnBack.setVerticalTextPosition(JButton.CENTER);
		    btnBack.setForeground(Color.white);
		    btnBack.setBounds(screenSize.width/2-screenSize.width/8, screenSize.height/8+screenSize.height/2, screenSize.width/4, 80);
	        frame.getContentPane().add(btnBack);
	        btnBack.addActionListener(this);
   	        frame.getContentPane().add(btnBack);
		    frame.getContentPane().add(label);
		    frame.getContentPane().add(backgroundImageLabel);
	      
	       
	       
	}
}
