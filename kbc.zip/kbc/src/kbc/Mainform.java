package kbc;

import java.awt.EventQueue;

import javax.swing.JFrame;

import java.awt.Color;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JPanel;

public class Mainform implements ActionListener{

	private JFrame frame;
	
	static List<Question> list=Resource.getQuestionList();
	
	static List<JButton> btnList=new ArrayList<JButton>();
	
	static JButton btnoption1, btnoption2,btnoption3,btnoption4,btn50_50,btnAudiance;
	
	static JTextArea textAreaQuestion;
	
	static JLabel lblNewLabel, lblB,lblC,lblD;
	
	static int count=-1;

	static JLabel lblJ1,lblJ2,lblJ3;
	
	static JButton btnq1, btnq2,btnq3,btnq4, btnq5 , btnq6,btnq7 , btnq8,btnq9, btnq10, btnq11, btnq12,btnq13,btnq14,btnq15;
	
	static List<JButton> btnQuestionList=new ArrayList<JButton>();
	static JLabel lblQuiz,gameover;
	

	

	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
		
		UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Mainform window = new Mainform();
					window.frame.setVisible(true);
					loadquestion();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			
		});
	}

	private static void loadquestion() {
		
		
		
		btnoption1.setVisible(true);
		btnoption2.setVisible(true);
		btnoption3.setVisible(true);
		btnoption4.setVisible(true);
		
		btnoption1.setBackground(Color.yellow);
		btnoption2.setBackground(Color.yellow);
		btnoption3.setBackground(Color.yellow);
		btnoption4.setBackground(Color.yellow);
		
		if(count<list.size()-1)
		{	
		count++;
		textAreaQuestion.setText(list.get(count).getQuestion());
		btnoption1.setText(list.get(count).getOption1());
		btnoption2.setText(list.get(count).getOption2());
		btnoption3.setText(list.get(count).getOption3());
		btnoption4.setText(list.get(count).getOption4());
		
		
		}
		else
			System.out.println("question ended");
	}
	/**
	 * Create the application.
	 */
	public Mainform() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("QUIZ");
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		
		btnoption3 = new JButton("\r\n");
		btnoption3.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnoption3.setBackground(Color.YELLOW);
		btnoption3.setBounds(357, 470, 172, 67);
		frame.getContentPane().add(btnoption3);
		
		btnoption1 = new JButton("");
		btnoption1.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnoption1.setBackground(Color.YELLOW);
		btnoption1.setBounds(357, 346, 172, 61);
		frame.getContentPane().add(btnoption1);
		
		btnoption2 = new JButton("");
		btnoption2.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnoption2.setBackground(Color.YELLOW);
		btnoption2.setBounds(658, 346, 179, 61);
		frame.getContentPane().add(btnoption2);
		
		btnoption4 = new JButton("");
		btnoption4.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnoption4.setBackground(Color.YELLOW);
		btnoption4.setBounds(658, 470, 179, 67);
		frame.getContentPane().add(btnoption4);
		
		textAreaQuestion = new JTextArea();
		textAreaQuestion.setFont(new Font("Tahoma", Font.BOLD, 18));
		textAreaQuestion.setEditable(false);
		textAreaQuestion.setBackground(Color.WHITE);
		textAreaQuestion.setBounds(357, 227, 522, 88);
		frame.getContentPane().add(textAreaQuestion);
		
		btnAudiance = new JButton("Audiance\r\n");
		btnAudiance.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnAudiance.setBounds(960, 25, 112, 23);
		frame.getContentPane().add(btnAudiance);
		
		JLabel lblNewLabel = new JLabel("A");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel.setBounds(333, 346, 14, 61);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblB = new JLabel("B");
		lblB.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblB.setBounds(634, 346, 14, 61);
		frame.getContentPane().add(lblB);
		
		JLabel lblC = new JLabel("C");
		lblC.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblC.setBounds(333, 472, 14, 67);
		frame.getContentPane().add(lblC);
		
		JLabel lblD = new JLabel("D");
		lblD.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblD.setBounds(634, 472, 14, 67);
		frame.getContentPane().add(lblD);
		
		btn50_50 = new JButton("50-50");
		btn50_50.setFont(new Font("Tahoma", Font.BOLD, 15));
		btn50_50.setBounds(847, 25, 103, 23);
		
		
		btnoption1.addActionListener(this);
		btnoption2.addActionListener(this);
		btnoption3.addActionListener(this);
		btnoption4.addActionListener(this);
		btn50_50.addActionListener(this);
		btnAudiance.addActionListener(this);
		
		btnList.add(btnoption1);
		btnList.add(btnoption2);
		btnList.add(btnoption3);
		btnList.add(btnoption4);
		
		frame.getContentPane().add(btn50_50);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(10, 25, 179, 214);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		btnq1 = new JButton("1");
		btnq1.setBounds(10, 180, 45, 23);
		panel.add(btnq1);
		
		btnq2 = new JButton("2");
		btnq2.setBounds(10, 146, 45, 23);
		panel.add(btnq2);
		
		btnq3 = new JButton("3");
		btnq3.setBounds(10, 108, 45, 23);
		panel.add(btnq3);
		
		btnq4 = new JButton("4");
		btnq4.setBounds(10, 74, 45, 23);
		panel.add(btnq4);
		
		btnq5 = new JButton("5");
		btnq5.setBounds(10, 40, 45, 23);
		panel.add(btnq5);
		
		lblJ1 = new JLabel("J1");
		lblJ1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblJ1.setBounds(10, 11, 39, 14);
		panel.add(lblJ1);
		
		btnq6 = new JButton("6");
		btnq6.setBounds(69, 180, 45, 23);
		panel.add(btnq6);
		
		btnq7 = new JButton("7");
		btnq7.setBounds(69, 146, 45, 23);
		panel.add(btnq7);
		
		btnq8 = new JButton("8");
		btnq8.setBounds(69, 108, 45, 23);
		panel.add(btnq8);
		
		btnq9 = new JButton("9");
		btnq9.setBounds(69, 74, 45, 23);
		panel.add(btnq9);
		
		btnq10 = new JButton("10");
		btnq10.setBounds(69, 40, 45, 23);
		panel.add(btnq10);
		
		lblJ2 = new JLabel("J2");
		lblJ2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblJ2.setBounds(68, 12, 46, 14);
		panel.add(lblJ2);
		
		btnq11 = new JButton("11");
		btnq11.setBounds(124, 180, 45, 23);
		panel.add(btnq11);
		
		btnq12 = new JButton("12");
		btnq12.setBounds(124, 146, 45, 23);
		panel.add(btnq12);
		
		btnq13 = new JButton("13");
		btnq13.setBounds(124, 108, 45, 23);
		panel.add(btnq13);
		
		btnq14 = new JButton("14");
		btnq14.setBounds(124, 74, 45, 23);
		panel.add(btnq14);
		
		btnq15 = new JButton("15");
		btnq15.setBounds(124, 40, 45, 23);
		panel.add(btnq15);
		
		lblJ3 = new JLabel("J3");
		lblJ3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblJ3.setBounds(124, 12, 46, 14);
		panel.add(lblJ3);
		
		btnQuestionList.add(btnq1);
		btnQuestionList.add(btnq2);
		btnQuestionList.add(btnq3);
		btnQuestionList.add(btnq4);
		btnQuestionList.add(btnq5);
		btnQuestionList.add(btnq6);
		btnQuestionList.add(btnq7);
		btnQuestionList.add(btnq8);
		btnQuestionList.add(btnq9);
		btnQuestionList.add(btnq10);
		btnQuestionList.add(btnq11);
		btnQuestionList.add(btnq12);
		btnQuestionList.add(btnq13);
		btnQuestionList.add(btnq14);
		btnQuestionList.add(btnq15);
		
		lblQuiz = new JLabel("QUIZ");
		lblQuiz.setFont(new Font("Tahoma", Font.BOLD, 36));
		lblQuiz.setBounds(357, 79, 371, 67);
		frame.getContentPane().add(lblQuiz);
		
		
		frame.setBackground(Color.WHITE);
		frame.setBounds(100, 100, 1098, 645);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//frame.setPreferredSize(new Dimension(700, 600));
		//	frame.pack();
	}

	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==btnoption1)
		{
			if(list.get(count).getCorrect().equalsIgnoreCase(btnoption1.getText()))
			{
				
				try {
					  
					   btnoption1.setBackground(Color.GREEN);
						
					   btnQuestionList.get(count).setBackground(Color.green);
					   File wavfile=new File("sound/applause4.wav");
					   Clip clip=AudioSystem.getClip();
					   clip.open(AudioSystem.getAudioInputStream(wavfile));
					   clip.start();
					
					   
					   Thread.sleep(clip.getMicrosecondLength()/1000);
				}
				catch (InterruptedException | LineUnavailableException | IOException | UnsupportedAudioFileException e1) {
					
					e1.printStackTrace();
				}
				loadquestion();
			}
			else
			{
				try {
						btnoption1.setBackground(Color.RED);
						btnQuestionList.get(count).setBackground(Color.RED);
						File wavfile=new File("sound/smb_mariodie.wav");
						Clip clip=AudioSystem.getClip();
						clip.open(AudioSystem.getAudioInputStream(wavfile));
						clip.start();
				   
						frame.getContentPane().removeAll();
				        gameover=new JLabel("Game Over");
				        gameover.setBounds(100, 50, 100, 20);
				        gameover.setVisible(true);
				        frame.getContentPane().repaint(); 
						frame.getContentPane().add(gameover);
						//Thread.sleep(clip.getMicrosecondLength()/1000);
				   
						//loadquestion();
				   
				}
				catch(Exception e1)
				{
					
				}
			}
		}
		else if(e.getSource()==btnoption2)
		{
			if(list.get(count).getCorrect().equalsIgnoreCase(btnoption2.getText()))
			{
				
				try {
						
					   btnoption2.setBackground(Color.GREEN);
						
					   btnQuestionList.get(count).setBackground(Color.green);
					   
					   File wavfile=new File("sound/applause4.wav");
					   Clip clip=AudioSystem.getClip();
					   clip.open(AudioSystem.getAudioInputStream(wavfile));
					   clip.start();
					  
					   
					   Thread.sleep(clip.getMicrosecondLength()/1000);
			} catch (InterruptedException | LineUnavailableException | IOException | UnsupportedAudioFileException e1) {
				
				e1.printStackTrace();
			}
				loadquestion();
			}
			else
			{
				try {
					   btnoption2.setBackground(Color.RED);
					   btnQuestionList.get(count).setBackground(Color.RED);
					   
					   File wavfile=new File("sound/smb_mariodie.wav");
					   Clip clip=AudioSystem.getClip();
					   clip.open(AudioSystem.getAudioInputStream(wavfile));
					   clip.start();
					   
					   frame.getContentPane().removeAll();
				       gameover=new JLabel("Game Over");
				       gameover.setBounds(100, 50, 100, 20);
				       gameover.setVisible(true);
				       frame.getContentPane().repaint(); 
				       frame.getContentPane().add(gameover);
					   
				      // Thread.sleep(clip.getMicrosecondLength()/1000);
					   //loadquestion();
					}
					catch(Exception e1)
					{
						
					}				
			}
		}
		else if(e.getSource()==btnoption3)
		{
			if(list.get(count).getCorrect().equalsIgnoreCase(btnoption3.getText()))
			{
				try {
				       btnoption3.setBackground(Color.GREEN);
					   btnQuestionList.get(count).setBackground(Color.green);
					   
					   File wavfile=new File("sound/applause4.wav");
					   Clip clip=AudioSystem.getClip();
					   clip.open(AudioSystem.getAudioInputStream(wavfile));
					   clip.start();
					   
					   
					   Thread.sleep(clip.getMicrosecondLength()/1000);
					   
			} catch (LineUnavailableException | IOException | UnsupportedAudioFileException | InterruptedException e1) {
				
				e1.printStackTrace();
			}
				loadquestion();
			}
			else
			{
				
				try {
					   btnoption3.setBackground(Color.RED);
					   btnQuestionList.get(count).setBackground(Color.RED);
					   
					   File wavfile=new File("sound/smb_mariodie.wav");
					   Clip clip=AudioSystem.getClip();
					   clip.open(AudioSystem.getAudioInputStream(wavfile));
					   clip.start();
					   
					 
					   
					   frame.getContentPane().removeAll();
				       gameover=new JLabel("Game Over");
				       gameover.setBounds(100, 50, 100, 20);
				       gameover.setVisible(true);
				       frame.getContentPane().repaint(); 
				       frame.getContentPane().add(gameover);
				      
				      // Thread.sleep(clip.getMicrosecondLength()/1000);
						//loadquestion();
					}
					catch(Exception e1)
					{
						
					}
				
			 
			}
		}
		else if(e.getSource()==btnoption4)
		{
			if(list.get(count).getCorrect().equalsIgnoreCase(btnoption4.getText()))
			{
				try {
					   btnoption4.setBackground(Color.GREEN);
					   btnQuestionList.get(count).setBackground(Color.green); 
					  
					   File wavfile=new File("sound/applause4.wav");
					   Clip clip=AudioSystem.getClip();
					   clip.open(AudioSystem.getAudioInputStream(wavfile));
					   clip.start();
					   
					   Thread.sleep(clip.getMicrosecondLength()/1000);
					
			} catch (InterruptedException | LineUnavailableException | IOException | UnsupportedAudioFileException e1) {
				
				e1.printStackTrace();
			}
				loadquestion();
			}
			else
			{
				try {
					   btnoption4.setBackground(Color.RED);
					   btnQuestionList.get(count).setBackground(Color.RED);
					   
					   File wavfile=new File("sound/smb_mariodie.wav");
					   Clip clip=AudioSystem.getClip();
					   clip.open(AudioSystem.getAudioInputStream(wavfile));
					   clip.start();
					   
					   frame.getContentPane().removeAll();
				       gameover=new JLabel("Game Over");
				       gameover.setBounds(100, 50, 100, 20);
				       gameover.setVisible(true);
				       frame.getContentPane().repaint(); 
				       frame.getContentPane().add(gameover);
					   
				       //Thread.sleep(clip.getMicrosecondLength()/1000);
					   
					   //loadquestion();
					}
					catch(Exception e1)
					{
						
					}
				
			 
			}
		}
		else if(e.getSource()==btn50_50)
		{
		    int i=0;
		    int index=0;
			while(i<2)
			{
				
				if(!list.get(count).getCorrect().equalsIgnoreCase(btnList.get(index).getText()))
				{
					btnList.get(index).setVisible(false);
					i++;
				}
				index++;
			}

			btn50_50.setEnabled(false);
				
		}
		else if(e.getSource()==btnAudiance)
		{
			
		}
		
		
	}
}
