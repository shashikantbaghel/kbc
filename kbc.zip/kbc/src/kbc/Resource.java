package kbc;

import java.util.ArrayList;
import java.util.List;

public class Resource {

	static List<Question> arrayList=new ArrayList<Question>();
	
	static List<Question> getQuestionList()
	{
		Question question=new Question();
		question.setQuestion("What is 2*2");
		question.setOption1("2");
		question.setOption2("3");
		question.setOption3("4");
		question.setOption4("5");
		question.setCorrect("4");
		
		Question question2=new Question();
		question2.setQuestion("What is 2*3");
		question2.setOption1("6");
		question2.setOption2("3");
		question2.setOption3("2");
		question2.setOption4("5");
		question2.setCorrect("6");
		
		Question question3=new Question();
		question3.setQuestion("Who is PM of India?");
		question3.setOption1("Narendra Modi");
		question3.setOption2("Rahul Gandhi");
		question3.setOption3("Soniya Gandhi");
		question3.setOption4("Rajnath Singh");
		question3.setCorrect("Narendra Modi");
		
		Question question4=new Question();
		question4.setQuestion("Who is CM of Delhi?");
		question4.setOption1("Narendra Modi");
		question4.setOption2("Arvind Kejriwal");
		question4.setOption3("Soniya Gandhi");
		question4.setOption4("Rajnath Singh");
		question4.setCorrect("Arvind Kejriwal");
		
		Question question5=new Question();
		question5.setQuestion("Who has been appointed as the new chairman of Central Board of Indirect taxes and Customs (CBIC)?");
		question5.setOption1("Johnjoseph");
		question5.setOption2("VanajaN.Sarna");
		question5.setOption3("MahenderSingh");
		question5.setOption4("S Ramesh");
		question5.setCorrect("S Ramesh");
		
		Question question6=new Question();
		question6.setQuestion("Pappu Karki, the popular Kumaoni folk singer has passed away. He was native of which state?");
		question6.setOption1("Jammu&Kashmir");
		question6.setOption2("HimachalPradesh");
		question6.setOption3("Uttarakhand");
		question6.setOption4("Assam");
		question6.setCorrect("Uttarakhand");
		
		Question question7=new Question();
		question7.setQuestion("India�s first-ever national police museum will establish in which city?");
		question7.setOption1("Chennai");
		question7.setOption2("Delhi");
		question7.setOption3("Nagpur");
		question7.setOption4("Kolkata");
		question7.setCorrect("Delhi");
		
		Question question8=new Question();
		question8.setQuestion("The Central Vigilance Commission (CVC) is in news for appointing Sharad Kumar as new Vigilance Commissioner. As per which committee�s recommendations, the CVC was set up?");
		question8.setOption1("NittoorSrinivasaRaucommiittee");
		question8.setOption2("TejendraMohanBhasincommiittee");
		question8.setOption3("KVChowdarycommiittee");
		question8.setOption4("K Santhanam commiittee");
		question8.setCorrect("K Santhanam commiittee");
		
		Question question9=new Question();
		question9.setQuestion("Which country will host the 45th G7 summit 2019?");
		question9.setOption1("Italy");
		question9.setOption2("Germany");
		question9.setOption3("France");
		question9.setOption4("Canada");
		question9.setCorrect("France");
		
		Question question10=new Question();
		question10.setQuestion("Which country�s women cricket team has clinched the Asia Cup Twenty-20 tournament 2018?");
		question10.setOption1("SouthKorea");
		question10.setOption2("Bangladesh");
		question10.setOption3("India");
		question10.setOption4("Pakistan");
		question10.setCorrect("Bangladesh");
		
		Question question11=new Question();
		question11.setQuestion("Who has won the men�s singles French Open tennis tournament 2018?");
		question11.setOption1("NovakDjokovic");
		question11.setOption2("DominicThiem");
		question11.setOption3("RogerFederer");
		question11.setOption4("Rafael Nadal");
		question11.setCorrect("Rafael Nadal");
		
		Question question12=new Question();
		question12.setQuestion("Which country�s football team has lifted the 2018 Intercontinental Cup football title?");
		question12.setOption1("India");
		question12.setOption2("SriLanka");
		question12.setOption3("Kenya");
		question12.setOption4("Argentina");
		question12.setCorrect("India");
		
		Question question13=new Question();
		question13.setQuestion("Shantaram Laxman Naik, who passed away recently, was the former Congress chief of which state?");
		question13.setOption1("Maharashtra");
		question13.setOption2("Goa");
		question13.setOption3("Bihar");
		question13.setOption4("Karnataka");
		question13.setCorrect("Goa");
		
		Question question14=new Question();
		question14.setQuestion("The Maratha and The Kesri were the two main newspapers started by?");
		question14.setOption1("Lala Lajpat Rai");
		question14.setOption2("Gopal Krishna Gokhale");
		question14.setOption3("Bal Gangadhar Tilak");
		question14.setOption4("Madan Mohan Malviya");
		question14.setCorrect("Bal Gangadhar Tilak");
		
		Question question15=new Question();
		question15.setQuestion("National emergency arising out of the war, armed rebellion or external aggression is dealt under?");
		question15.setOption1("Article 280");
		question15.setOption2("Article 352");
		question15.setOption3("Article 356");
		question15.setOption4("Article 370");
		question15.setCorrect("Article 352");
		
		arrayList.add(question6);
		arrayList.add(question2);
		arrayList.add(question3);
		arrayList.add(question4);
		arrayList.add(question5);
		arrayList.add(question);
		arrayList.add(question7);
		arrayList.add(question8);
		arrayList.add(question9);
		arrayList.add(question10);
		arrayList.add(question11);
		arrayList.add(question12);
		arrayList.add(question13);
		arrayList.add(question14);
		arrayList.add(question15);
		return arrayList;
		
	}
	
}
