package kbc;

import java.util.ArrayList;
import java.util.List;

public class Resource {

	static List<Question> arrayList=new ArrayList<Question>();
	
	static List<Question> getQuestionList()
	{
		Question question=new Question();
		question.setQuestion("What is 2*2");
		question.setOption1("2");
		question.setOption2("3");
		question.setOption3("4");
		question.setOption4("5");
		question.setCorrect("4");
		
		Question question2=new Question();
		question2.setQuestion("What is 2*3");
		question2.setOption1("6");
		question2.setOption2("3");
		question2.setOption3("2");
		question2.setOption4("5");
		question2.setCorrect("6");
		
		Question question3=new Question();
		question3.setQuestion("Who is PM of India?");
		question3.setOption1("Narendra Modi");
		question3.setOption2("Rahul Gandhi");
		question3.setOption3("Soniya Gandhi");
		question3.setOption4("Rajnath Singh");
		question3.setCorrect("Narendra Modi");
		
		
		arrayList.add(question);
		arrayList.add(question2);
		arrayList.add(question3);
		return arrayList;
		
	}
	
}
